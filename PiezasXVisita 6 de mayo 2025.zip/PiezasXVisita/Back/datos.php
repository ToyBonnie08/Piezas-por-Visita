<?php 
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("conexion.php");

if ($conexion->connect_error) {
    echo json_encode(['error' => 'Error de conexión: ' . $conexion->connect_error]);
    exit;
}

$inicio = $_GET['inicio'] ?? null;
$fin = $_GET['fin'] ?? null;
$modo = $_GET['modo'] ?? 'diario';

if (!$inicio || !$fin) {
    echo json_encode(['error' => 'Fechas no válidas']);
    exit;
}

$dateStart = new DateTime($inicio);
$dateEnd = new DateTime($fin);
if ($dateStart > $dateEnd) {
    echo json_encode(['error' => 'La fecha de inicio no puede ser mayor que la fecha final']);
    exit;
}

$groupBy = "fecha";
$orderBy = "fecha ASC";
$selectFecha = "fecha";

if ($modo === 'semana') {
    $groupBy = "YEARWEEK(fecha, 1)";
    $orderBy = "$groupBy ASC";
    $selectFecha = "YEARWEEK(fecha, 1) AS semana";
} elseif ($modo === 'mes') {
    $groupBy = "DATE_FORMAT(fecha, '%Y-%m')";
    $orderBy = "$groupBy ASC";
    $selectFecha = "DATE_FORMAT(fecha, '%Y-%m') AS mes";
}

function formatearSemana($yearWeek) {
    $year = substr($yearWeek, 0, 4);
    $week = substr($yearWeek, -2);

    $dto = new DateTime();
    $dto->setISODate($year, $week);
    $inicio = $dto->format('j');
    $mesInicio = strtolower($dto->format('M'));

    $dto->modify('+6 days');
    $fin = $dto->format('j');
    $mesFin = strtolower($dto->format('M'));

    $rango = ($mesInicio === $mesFin)
        ? "$inicio-$fin $mesFin"
        : "$inicio $mesInicio - $fin $mesFin";

    return "Semana $week ($rango)";
}

function formatearMes($mesAño) {
    $fecha = DateTime::createFromFormat('Y-m', $mesAño);
    return $fecha ? $fecha->format('F Y') : $mesAño;
}

// ---------- Fechas base ----------
$fechas = [];

$sql = "SELECT DISTINCT $selectFecha FROM reporte WHERE fecha BETWEEN ? AND ? ORDER BY $orderBy";
$stmt = $conexion->prepare($sql);
$stmt->bind_param('ss', $inicio, $fin);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $fechaKey = ($modo === 'semana') ? formatearSemana($row['semana']) :
                (($modo === 'mes') ? formatearMes($row['mes']) : $row['fecha']);
    $fechas[] = $fechaKey;
}

// ---------- Visitas por tipo de Cliente (1 letra: A, B, C, D) ----------
$clientesPorFecha = [];

$sqlClientes = "SELECT LEFT(b.nombre, 1) AS tipo_cliente, $selectFecha, COUNT(*) AS total
                FROM reporte a
                LEFT JOIN cliente b ON a.Cliente_Id = b.id
                WHERE a.fecha BETWEEN ? AND ?
                GROUP BY tipo_cliente, $groupBy
                ORDER BY $orderBy, tipo_cliente";
$stmtClientes = $conexion->prepare($sqlClientes);
$stmtClientes->bind_param('ss', $inicio, $fin);
$stmtClientes->execute();
$resultClientes = $stmtClientes->get_result();

$tiposClientes = [];

while ($row = $resultClientes->fetch_assoc()) {
    $fechaKey = ($modo === 'semana') ? formatearSemana($row[$modo === 'semana' ? 'semana' : 'fecha']) :
                (($modo === 'mes') ? formatearMes($row[$modo === 'mes' ? 'mes' : 'fecha']) : $row['fecha']);

    $tipo = $row['tipo_cliente'];
    $tiposClientes[$tipo] = true;

    if (!isset($clientesPorFecha[$tipo])) {
        $clientesPorFecha[$tipo] = [];
    }

    $clientesPorFecha[$tipo][$fechaKey] = $row['total'];
}

$clientesSeries = [];
foreach (array_keys($tiposClientes) as $tipo) {
    $serie = [];
    foreach ($fechas as $fecha) {
        $serie[] = $clientesPorFecha[$tipo][$fecha] ?? 0;
    }
    $clientesSeries[] = [
        'label' => "Maquina $tipo",
        'data' => $serie
    ];
}

// ---------- CONSULTA 1: Visitas ----------
$visitas = [];
$sqlVisitas = "SELECT COUNT(Visita_Id) AS total_visitas, $selectFecha 
               FROM reporte 
               WHERE fecha BETWEEN ? AND ? 
               GROUP BY $groupBy 
               ORDER BY $orderBy";
$stmtVisitas = $conexion->prepare($sqlVisitas);
$stmtVisitas->bind_param('ss', $inicio, $fin);
$stmtVisitas->execute();
$resultVisitas = $stmtVisitas->get_result();

while ($row = $resultVisitas->fetch_assoc()) {
    $fechaKey = ($modo === 'semana') ? formatearSemana($row['semana']) :
                (($modo === 'mes') ? formatearMes($row['mes']) : $row['fecha']);
    $visitas[] = $row['total_visitas'];
}

// ---------- CONSULTA 2: Promedio Vendidos ----------
$diferencias_valor = [];
$sqlDiferencias = "SELECT ROUND(AVG(Vendidos)) AS total_diferencia, $selectFecha 
                   FROM reporte 
                   WHERE fecha BETWEEN ? AND ? 
                   GROUP BY $groupBy 
                   ORDER BY $orderBy";
$stmtDiferencias = $conexion->prepare($sqlDiferencias);
$stmtDiferencias->bind_param('ss', $inicio, $fin);
$stmtDiferencias->execute();
$resultDiferencias = $stmtDiferencias->get_result();

$diferenciasPorFecha = [];
while ($row = $resultDiferencias->fetch_assoc()) {
    $fechaKey = ($modo === 'semana') ? formatearSemana($row['semana']) :
                (($modo === 'mes') ? formatearMes($row['mes']) : $row['fecha']);
    $diferenciasPorFecha[$fechaKey] = $row['total_diferencia'];
}

foreach ($fechas as $f) {
    $diferencias_valor[] = $diferenciasPorFecha[$f] ?? 0;
}

// ---------- CONSULTA 3: % Lleno Inicial y Final ----------
$llenoPorFecha = [];
$llenoFinalPorFecha = [];

$sqlLleno = "SELECT $selectFecha, 
                    SUM(ConteoProductoFisico) AS total_fisico, 
                    SUM(espaciosVacios) AS total_vacios, 
                    SUM(espaciosTotales) AS total_totales,
                    SUM(Colocados) AS colocados
             FROM reporte 
             WHERE fecha BETWEEN ? AND ? 
             GROUP BY $groupBy 
             ORDER BY $orderBy";
$stmtLleno = $conexion->prepare($sqlLleno);
$stmtLleno->bind_param('ss', $inicio, $fin);
$stmtLleno->execute();
$resultLleno = $stmtLleno->get_result();

while ($row = $resultLleno->fetch_assoc()) {
    $fechaKey = ($modo === 'semana') ? formatearSemana($row['semana']) :
                (($modo === 'mes') ? formatearMes($row['mes']) : $row['fecha']);

    $total = $row['total_totales'];
    $vacios = $row['total_vacios'];
    $colocados = $row['colocados'];

    $porcentajeInicial = ($total > 0) ? round((($total - $vacios - $colocados) / $total) * 100, 2) : 0;
    $porcentajeFinal = ($total > 0) ? round((($total - $vacios) / $total) * 100, 2) : 0;

    $llenoPorFecha[$fechaKey] = $porcentajeInicial;
    $llenoFinalPorFecha[$fechaKey] = $porcentajeFinal;
}

$lleno_inicial = [];
$lleno_final = [];
foreach ($fechas as $f) {
    $lleno_inicial[] = $llenoPorFecha[$f] ?? 0;
    $lleno_final[] = $llenoFinalPorFecha[$f] ?? 0;
}

$llenoPorTipo = [];

$sqlLlenoPorTipo = "SELECT LEFT(b.nombre, 1) AS tipo_cliente, $selectFecha,
                           SUM(ConteoProductoFisico) AS total_fisico, 
                           SUM(espaciosVacios) AS total_vacios, 
                           SUM(espaciosTotales) AS total_totales,
                           SUM(Colocados) AS colocados
                    FROM reporte a
                    LEFT JOIN cliente b ON a.Cliente_Id = b.id
                    WHERE a.fecha BETWEEN ? AND ?
                    GROUP BY tipo_cliente, $groupBy
                    ORDER BY tipo_cliente, $orderBy";
$stmtLlenoTipo = $conexion->prepare($sqlLlenoPorTipo);
$stmtLlenoTipo->bind_param('ss', $inicio, $fin);
$stmtLlenoTipo->execute();
$resultLlenoTipo = $stmtLlenoTipo->get_result();

while ($row = $resultLlenoTipo->fetch_assoc()) {
    $fechaKey = ($modo === 'semana') ? formatearSemana($row['semana']) :
                (($modo === 'mes') ? formatearMes($row['mes']) : $row['fecha']);

    $tipo = $row['tipo_cliente'];
    if (!isset($llenoPorTipo[$tipo])) $llenoPorTipo[$tipo] = [];
    
    $total = $row['total_totales'];
    $vacios = $row['total_vacios'];
    $colocados = $row['colocados'];

    $porcentajeInicial = ($total > 0) ? round((($total - $vacios - $colocados) / $total) * 100, 2) : 0;
    $porcentajeFinal = ($total > 0) ? round((($total - $vacios) / $total) * 100, 2) : 0;

    $llenoPorTipo[$tipo][$fechaKey] = [
        'inicial' => $porcentajeInicial,
        'final' => $porcentajeFinal
    ];
}

$sqlVendidosPorTipo = "SELECT LEFT(b.nombre, 1) AS tipo_cliente, $selectFecha, SUM(a.Vendidos) AS total_vendidos
                       FROM reporte a
                       LEFT JOIN cliente b ON a.Cliente_Id = b.id
                       WHERE a.fecha BETWEEN ? AND ?
                       GROUP BY tipo_cliente, $groupBy
                       ORDER BY tipo_cliente, $orderBy";
$stmtVendidosPorTipo = $conexion->prepare($sqlVendidosPorTipo);
$stmtVendidosPorTipo->bind_param('ss', $inicio, $fin);
$stmtVendidosPorTipo->execute();
$resultVendidosPorTipo = $stmtVendidosPorTipo->get_result();

$vendidosPorFecha = [];
$vendidosPorTipo = [];

while ($row = $resultVendidosPorTipo->fetch_assoc()) {
    $fechaKey = ($modo === 'semana') ? formatearSemana($row['semana']) :
                (($modo === 'mes') ? formatearMes($row['mes']) : $row['fecha']);
    
    $tipo = $row['tipo_cliente'];

    if (!isset($vendidosPorTipo[$tipo])) {
        $vendidosPorTipo[$tipo] = [];
    }

    $vendidosPorTipo[$tipo][$fechaKey] = $row['total_vendidos'];
}

// ---------- Agregar la serie de vendidos para cada máquina (tipo cliente) ----------
$vendidosSeries = [];
foreach (array_keys($tiposClientes) as $tipo) {
    $serie = [];
    foreach ($fechas as $fecha) {
        $serie[] = $vendidosPorTipo[$tipo][$fecha] ?? 0;
    }
    $vendidosSeries[] = [
        'label' => "Maquina $tipo",
        'data' => $serie
    ];
}

$promedioVendidosPorVisita = [];

foreach (array_keys($tiposClientes) as $tipo) {
    $serie = [];
    foreach ($fechas as $fecha) {
        $vendidos = $vendidosPorTipo[$tipo][$fecha] ?? 0;
        $visitas = $clientesPorFecha[$tipo][$fecha] ?? 0;
        $promedio = ($visitas > 0) ? round($vendidos / $visitas, 2) : 0;
        $serie[] = $promedio;
    }
    $promedioVendidosPorVisita[] = [
       'label' => "Maquina $tipo", 
        'data' => $serie
    ];
}

// ---------- RESPUESTA JSON con los vendidos por máquina ----------

echo json_encode([
    'modo' => $modo,
    'fechas' => $fechas,
    'visitas' => $visitas,
    'diferencias_valores' => $diferencias_valor,
    'lleno_inicial' => $lleno_inicial,
    'lleno_final' => $lleno_final,
    'clientes_series' => $clientesSeries,
    'lleno_por_tipo' => $llenoPorTipo,
    'promedio_vendidos_por_visita' => $promedioVendidosPorVisita,
    'vendidos_series' => $vendidosSeries  // Aquí añadimos la serie de vendidos por máquina
]);
?>